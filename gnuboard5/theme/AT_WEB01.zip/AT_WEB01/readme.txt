﻿Theme Name: [골뱅이] 반응형_WEB01
Theme URI: http://atstore.co.kr/at01/
Maker: 골뱅이스토어
Maker URI: http://atstore.co.kr
Version: 1.0.0
Detail: 반응형_WEB01 테마는 골뱅이스토어에서 제작하는 테마입니다. 반응형_WEB01 테마는 웹표준 및 접근성을 준수합니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html